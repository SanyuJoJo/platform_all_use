| Family         | Implementation Version                                | Variant         | NIST round   |   Claimed NIST Level | Code Point   | Hybrid Elliptic Curve (if any)   |
|:---------------|:------------------------------------------------------|:----------------|:-------------|---------------------:|:-------------|:---------------------------------|
| BIKE           | 5.1                                                   | bikel1          | 4            |                    1 | 65040        |                                  |
| BIKE           | 5.1                                                   | bikel1          | 4            |                    1 | 65041        | secp256_r1                       |
| BIKE           | 5.1                                                   | bikel1          | 4            |                    1 | 65042        | x25519                           |
| BIKE           | 5.1                                                   | bikel3          | 4            |                    3 | 65043        |                                  |
| BIKE           | 5.1                                                   | bikel3          | 4            |                    3 | 65044        | secp384_r1                       |
| BIKE           | 5.1                                                   | bikel3          | 4            |                    3 | 65045        | x448                             |
| BIKE           | 5.1                                                   | bikel5          | 4            |                    5 | 65046        |                                  |
| BIKE           | 5.1                                                   | bikel5          | 4            |                    5 | 65047        | secp521_r1                       |
| BIKE           | NIST Round 2 submission                               | bike1l1cpa      | 2            |                    1 | 0x0206       |                                  |
| BIKE           | NIST Round 2 submission                               | bike1l1cpa      | 2            |                    1 | 0x2F06       | secp256_r1                       |
| BIKE           | NIST Round 2 submission                               | bike1l1fo       | 2            |                    1 | 0x0223       |                                  |
| BIKE           | NIST Round 2 submission                               | bike1l1fo       | 2            |                    1 | 0x2F23       | secp256_r1                       |
| BIKE           | NIST Round 2 submission                               | bike1l1fo       | 2            |                    1 | 0x2F28       | x25519                           |
| BIKE           | NIST Round 2 submission                               | bike1l3cpa      | 2            |                    3 | 0x0207       |                                  |
| BIKE           | NIST Round 2 submission                               | bike1l3cpa      | 2            |                    3 | 0x2F07       | secp384_r1                       |
| BIKE           | NIST Round 2 submission                               | bike1l3fo       | 2            |                    3 | 0x0224       |                                  |
| BIKE           | NIST Round 2 submission                               | bike1l3fo       | 2            |                    3 | 0x2F24       | secp384_r1                       |
| BIKE           | NIST Round 3 submission                               | bikel1          | 3            |                    1 | 0x0238       |                                  |
| BIKE           | NIST Round 3 submission                               | bikel1          | 3            |                    1 | 0x2F37       | x25519                           |
| BIKE           | NIST Round 3 submission                               | bikel1          | 3            |                    1 | 0x2F38       | secp256_r1                       |
| BIKE           | NIST Round 3 submission                               | bikel3          | 3            |                    3 | 0x023B       |                                  |
| BIKE           | NIST Round 3 submission                               | bikel3          | 3            |                    3 | 0x2F3B       | secp384_r1                       |
| CRYSTALS-Kyber | NIST Round 2 submission                               | kyber1024       | 2            |                    5 | 0x0211       |                                  |
| CRYSTALS-Kyber | NIST Round 2 submission                               | kyber1024       | 2            |                    5 | 0x2F11       | secp521_r1                       |
| CRYSTALS-Kyber | NIST Round 2 submission                               | kyber512        | 2            |                    1 | 0x020F       |                                  |
| CRYSTALS-Kyber | NIST Round 2 submission                               | kyber512        | 2            |                    1 | 0x2F0F       | secp256_r1                       |
| CRYSTALS-Kyber | NIST Round 2 submission                               | kyber512        | 2            |                    1 | 0x2F26       | x25519                           |
| CRYSTALS-Kyber | NIST Round 2 submission                               | kyber768        | 2            |                    3 | 0x0210       |                                  |
| CRYSTALS-Kyber | NIST Round 2 submission                               | kyber768        | 2            |                    3 | 0x2F10       | secp384_r1                       |
| CRYSTALS-Kyber | NIST Round 2 submission                               | kyber90s1024    | 2            |                    5 | 0x022B       |                                  |
| CRYSTALS-Kyber | NIST Round 2 submission                               | kyber90s1024    | 2            |                    5 | 0x2F2B       | secp521_r1                       |
| CRYSTALS-Kyber | NIST Round 2 submission                               | kyber90s512     | 2            |                    1 | 0x0229       |                                  |
| CRYSTALS-Kyber | NIST Round 2 submission                               | kyber90s512     | 2            |                    1 | 0x2F29       | secp256_r1                       |
| CRYSTALS-Kyber | NIST Round 2 submission                               | kyber90s768     | 2            |                    3 | 0x022A       |                                  |
| CRYSTALS-Kyber | NIST Round 2 submission                               | kyber90s768     | 2            |                    3 | 0x2F2A       | secp384_r1                       |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber1024       | 3            |                    5 | 0x023D       |                                  |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber1024       | 3            |                    5 | 0x2F3D       | secp521_r1                       |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber512        | 3            |                    1 | 0x023A       |                                  |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber512        | 3            |                    1 | 0x2F39       | x25519                           |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber512        | 3            |                    1 | 0x2F3A       | secp256_r1                       |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber768        | 3            |                    3 | 0x023C       |                                  |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber768        | 3            |                    3 | 0x2F3C       | secp384_r1                       |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber768        | 3            |                    3 | 0x2F90       | x448                             |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber768        | 3            |                    3 | 0x6399       | x25519                           |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber768        | 3            |                    3 | 0x639A       | secp256_r1                       |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber90s1024    | 3            |                    5 | 0x0240       |                                  |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber90s1024    | 3            |                    5 | 0x2F40       | secp521_r1                       |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber90s512     | 3            |                    1 | 0x023E       |                                  |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber90s512     | 3            |                    1 | 0x2F3E       | secp256_r1                       |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber90s512     | 3            |                    1 | 0x2FA9       | x25519                           |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber90s768     | 3            |                    3 | 0x023F       |                                  |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber90s768     | 3            |                    3 | 0x2F3F       | secp384_r1                       |
| CRYSTALS-Kyber | NIST Round 3 submission                               | kyber90s768     | 3            |                    3 | 0x2FAA       | x448                             |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo1344aes   | 3            |                    5 | 65036        |                                  |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo1344aes   | 3            |                    5 | 65037        | secp521_r1                       |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo1344shake | 3            |                    5 | 65038        |                                  |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo1344shake | 3            |                    5 | 65039        | secp521_r1                       |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo640aes    | 3            |                    1 | 65024        |                                  |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo640aes    | 3            |                    1 | 65025        | secp256_r1                       |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo640aes    | 3            |                    1 | 65026        | x25519                           |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo640shake  | 3            |                    1 | 65027        |                                  |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo640shake  | 3            |                    1 | 65028        | secp256_r1                       |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo640shake  | 3            |                    1 | 65029        | x25519                           |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo976aes    | 3            |                    3 | 65030        |                                  |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo976aes    | 3            |                    3 | 65031        | secp384_r1                       |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo976aes    | 3            |                    3 | 65032        | x448                             |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo976shake  | 3            |                    3 | 65033        |                                  |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo976shake  | 3            |                    3 | 65034        | secp384_r1                       |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | efrodo976shake  | 3            |                    3 | 65035        | x448                             |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo1344aes    | 3            |                    5 | 65071        |                                  |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo1344aes    | 3            |                    5 | 65072        | secp521_r1                       |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo1344shake  | 3            |                    5 | 65073        |                                  |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo1344shake  | 3            |                    5 | 65074        | secp521_r1                       |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo640aes     | 3            |                    1 | 65059        |                                  |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo640aes     | 3            |                    1 | 65060        | secp256_r1                       |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo640aes     | 3            |                    1 | 65061        | x25519                           |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo640shake   | 3            |                    1 | 65062        |                                  |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo640shake   | 3            |                    1 | 65063        | secp256_r1                       |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo640shake   | 3            |                    1 | 65064        | x25519                           |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo976aes     | 3            |                    3 | 65065        |                                  |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo976aes     | 3            |                    3 | 65066        | secp384_r1                       |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo976aes     | 3            |                    3 | 65067        | x448                             |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo976shake   | 3            |                    3 | 65068        |                                  |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo976shake   | 3            |                    3 | 65069        | secp384_r1                       |
| FrodoKEM       | ISO Preliminary Standardization Proposal - 2023/03/14 | frodo976shake   | 3            |                    3 | 65070        | x448                             |
| HQC            | NIST Round 3 submission                               | hqc1            | 3            |                    1 | 0x022C       |                                  |
| HQC            | NIST Round 3 submission                               | hqc1            | 3            |                    1 | 0x2F2C       | secp256_r1                       |
| HQC            | NIST Round 3 submission                               | hqc1            | 3            |                    1 | 0x2FAC       | x25519                           |
| HQC            | NIST Round 3 submission                               | hqc3            | 3            |                    3 | 0x022D       |                                  |
| HQC            | NIST Round 3 submission                               | hqc3            | 3            |                    3 | 0x2F2D       | secp384_r1                       |
| HQC            | NIST Round 3 submission                               | hqc3            | 3            |                    3 | 0x2FAD       | x448                             |
| HQC            | NIST Round 3 submission                               | hqc5            | 3            |                    5 | 0x022E       |                                  |
| HQC            | NIST Round 3 submission                               | hqc5            | 3            |                    5 | 0x2F2E       | secp521_r1                       |
| HQC            | NIST Round 4 submission                               | hqc1            | 4            |                    1 | 65048        |                                  |
| HQC            | NIST Round 4 submission                               | hqc1            | 4            |                    1 | 65049        | secp256_r1                       |
| HQC            | NIST Round 4 submission                               | hqc1            | 4            |                    1 | 65050        | x25519                           |
| HQC            | NIST Round 4 submission                               | hqc3            | 4            |                    3 | 65051        |                                  |
| HQC            | NIST Round 4 submission                               | hqc3            | 4            |                    3 | 65052        | secp384_r1                       |
| HQC            | NIST Round 4 submission                               | hqc3            | 4            |                    3 | 65053        | x448                             |
| HQC            | NIST Round 4 submission                               | hqc5            | 4            |                    5 | 65054        |                                  |
| HQC            | NIST Round 4 submission                               | hqc5            | 4            |                    5 | 65055        | secp521_r1                       |
| HQC            | 2025-08-22                                            | hqc1            | 4            |                    1 | 65075        |                                  |
| HQC            | 2025-08-22                                            | hqc1            | 4            |                    1 | 65076        | secp256_r1                       |
| HQC            | 2025-08-22                                            | hqc1            | 4            |                    1 | 65077        | x25519                           |
| HQC            | 2025-08-22                                            | hqc3            | 4            |                    3 | 65078        |                                  |
| HQC            | 2025-08-22                                            | hqc3            | 4            |                    3 | 65079        | secp384_r1                       |
| HQC            | 2025-08-22                                            | hqc3            | 4            |                    3 | 65080        | x448                             |
| HQC            | 2025-08-22                                            | hqc5            | 4            |                    5 | 65081        |                                  |
| HQC            | 2025-08-22                                            | hqc5            | 4            |                    5 | 65082        | secp521_r1                       |
| ML-KEM         | ML-KEM                                                | mlkem1024       | FIPS203      |                    5 | 0x11ED       | secp384_r1                       |
| ML-KEM         | ML-KEM                                                | mlkem1024       | FIPS203      |                    5 | 0x2F4D       | secp521_r1                       |
| ML-KEM         | ML-KEM                                                | mlkem1024       | FIPS203      |                    5 | 514          |                                  |
| ML-KEM         | ML-KEM                                                | mlkem1024       | FIPS203      |                    5 | 65058        | bp512                            |
| ML-KEM         | ML-KEM                                                | mlkem512        | FIPS203      |                    1 | 0x11e9       | secp256_r1                       |
| ML-KEM         | ML-KEM                                                | mlkem512        | FIPS203      |                    1 | 0x11ea       | x25519                           |
| ML-KEM         | ML-KEM                                                | mlkem512        | FIPS203      |                    1 | 512          |                                  |
| ML-KEM         | ML-KEM                                                | mlkem512        | FIPS203      |                    1 | 65056        | bp256                            |
| ML-KEM         | ML-KEM                                                | mlkem768        | FIPS203      |                    3 | 0x11eb       | secp256_r1                       |
| ML-KEM         | ML-KEM                                                | mlkem768        | FIPS203      |                    3 | 0x11ec       | x25519                           |
| ML-KEM         | ML-KEM                                                | mlkem768        | FIPS203      |                    3 | 0x2F4C       | secp384_r1                       |
| ML-KEM         | ML-KEM                                                | mlkem768        | FIPS203      |                    3 | 0x2FB7       | x448                             |
| ML-KEM         | ML-KEM                                                | mlkem768        | FIPS203      |                    3 | 513          |                                  |
| ML-KEM         | ML-KEM                                                | mlkem768        | FIPS203      |                    3 | 65057        | bp384                            |
